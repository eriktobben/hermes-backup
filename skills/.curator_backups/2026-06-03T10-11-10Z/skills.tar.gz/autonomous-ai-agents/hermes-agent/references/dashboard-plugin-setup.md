# Dashboard Plugin Setup & Verification (Hermes)

Session-derived quick recipe for installing third-party Hermes dashboard plugins from GitHub.

## Known-good sequence

```bash
mkdir -p ~/.hermes/plugins
git clone https://github.com/stainlu/hermes-labyrinth.git ~/.hermes/plugins/hermes-labyrinth

# optional theme
mkdir -p ~/.hermes/dashboard-themes
cp ~/.hermes/plugins/hermes-labyrinth/theme/hermes-labyrinth.yaml ~/.hermes/dashboard-themes/

# optional plugin self-checks
cd ~/.hermes/plugins/hermes-labyrinth
npm install --no-audit --no-fund
npm test

# start dashboard + rescan
hermes dashboard
curl -s http://127.0.0.1:9119/api/dashboard/plugins/rescan
curl -m 3 -s http://127.0.0.1:9119/api/dashboard/plugins
```

## Verification signal

A valid plugin object should appear in `/api/dashboard/plugins`, e.g. for Labyrinth:
- `name: "hermes-labyrinth"`
- `label: "Labyrinth"`
- `tab.path: "/labyrinth"`

## Pitfalls

- `curl` to `/api/dashboard/plugins` may fail with HTTP `000` if dashboard is not up yet.
- Check root readiness first:
  ```bash
  curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:9119/
  ```
- Use `curl -m 3` to avoid hanging checks.
