# Dashboard Plugin Runtime Debug (Blank/Dark Tab)

Use this when a Hermes dashboard plugin appears in `/api/dashboard/plugins` but clicking its tab makes the content area blank/dark.

## Symptom pattern
- Plugin is registered and visible in dashboard plugin list.
- Route changes (e.g. `/labyrinth`) but plugin root UI does not render.
- Dashboard shell remains, plugin pane appears empty.

## Likely cause
A frontend runtime exception inside the plugin bundle (`dashboard-plugins/<name>/dist/index.js`) during render. This is often caused by strict assumptions about API field types.

Example seen in session:
- `TypeError: j.started_at.split is not a function`
- Cause: plugin assumed `started_at` is always a string, but API returned non-string for some journeys.

## Fast verification workflow
1. Confirm plugin registration:
```bash
curl -m 3 -s http://127.0.0.1:9119/api/dashboard/plugins
```
2. Trigger plugin load and capture JS runtime errors with headless CDP script.
3. If error points into plugin dist bundle, patch source under `src/parts/*` (or source tree), rebuild, and rescan.

## Fix pattern
- Replace brittle string operations (`value.split(" ")`) on API fields with tolerant formatters.
- Prefer existing normalization helpers (e.g. `clock(value)`, `formatDateTime(value)`) that accept string/timestamp variants.

## Rebuild + reload
```bash
npm run build
npm run check
curl -m 3 -s http://127.0.0.1:9119/api/dashboard/plugins/rescan
```
Then hard-refresh browser (`Ctrl+Shift+R`).

## Notes
- `curl` checks can hang without timeout; use `-m 3`.
- `browser_navigate` may time out on local dashboard; terminal + headless Chrome CDP can be more reliable for JS exception capture.
