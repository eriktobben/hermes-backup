---
name: norway-used-car-evaluation
description: Evaluate used-car options in Norway with strict monthly-loan caps, compare EV vs petrol/hybrid tradeoffs, and pull concrete FINN listings with image/link evidence.
---

# Norway used car evaluation

## When to use
- User wants help choosing between EV and petrol/hybrid in Norway.
- User provides a hard monthly budget and down payment.
- User wants concrete FINN candidates (links + images), not only generic model advice.

## Core outcomes
1. Convert monthly payment + down payment + term into a realistic car-price range.
2. Explain EV vs petrol/hybrid tradeoffs for the user’s charging reality.
3. Return a shortlist of concrete listings with direct links and image URLs.

## Workflow
1. **Collect minimum decision inputs**
   - km/month or km/year
   - loan-only vs total-cost budget
   - ownership horizon (years)
   - home charging availability
   - transmission requirement
   - size/use constraints

2. **Compute affordability envelope (always calculate, don’t eyeball)**
   - Use amortized loan PV formula across plausible interest band (e.g., 4–10%).
   - Add user down payment.
   - Reserve a buffer for fees/registration before setting target listing price.

3. **Decision framing**
   - If no home charging: explicitly warn that EV fast-charging can erase fuel-cost advantage.
   - If user requests long winter intercity EV legs with limited charging stops: require extra real-world range margin vs WLTP.
   - For petrol constraint questions (timing chain vs belt): keep shortlist aligned with user’s mechanical constraints.

4. **Pull live market examples (FINN)**
   - Provide **actual listing URLs + image URLs**.
   - Filter out lease/promoted entries when user is buying.
   - Prefer models aligned to user constraints (automatic, reliability-first, low running risk).

5. **Present shortlist clearly**
   - Group by powertrain (hybrid/petrol/EV).
   - Include why each candidate fits, plus one “check before buy” note per car.

## Pitfalls
- Returning only model names without live listings when user asked to check FINN.
- Mixing lease campaign ads with purchase candidates.
- Over-trusting WLTP for winter route feasibility.
- Ignoring user clarification that changes financing horizon (3y vs 5–8y materially changes budget).

## Output template
- `Budsjett (beregnet): [range]`
- `Anbefalt drivlinje gitt lading: [reasoned choice]`
- `Aktuelle annonser:`
  - `Model, year, km`
  - `FINN link`
  - `Image`
  - `Why fit + what to verify`

## References
- See `references/finn-html-extraction-notes.md` for FINN extraction pattern and session-derived guardrails.