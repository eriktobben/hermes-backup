# FINN HTML extraction notes (cars)

## Why this exists
Browser navigation can time out on FINN in some sessions; HTML fetch + parsing still yields usable listing data for evidence-backed recommendations.

## Durable extraction pattern
1. Request FINN mobility search page with a normal browser User-Agent.
2. Parse repeated `<article ... sf-search-ad ...>` blocks.
3. Extract per listing:
   - title (`<h2 ...>`)
   - listing URL (`https://www.finn.no/mobility/item/<id>`)
   - image URL (`https://images.finncdn.no/dynamic/480w/item/...`)
   - meta row (year, km, fuel, transmission)
   - subtitle/description
4. Deduplicate by listing URL.
5. Exclude entries with obvious lease wording when user asked to buy (e.g., `Leasing`, `0% rente kampanje` in subtitle).

## Practical cautions
- FINN result pages can include sponsored/lease-heavy inventory; strict filtering is required.
- Query parameters can drift; rely on robust block parsing rather than fragile single selectors.
- Keep outputs human-usable: include direct clickable link + image URL for each candidate.

## Finance guardrail used with these listings
When user gives a strict monthly loan cap and down payment, compute affordability first and only then shortlist listings likely inside target price envelope.